CREATE PROC spHello
AS
BEGIN
PRINT 'Hello Anonymous Block'
END
go

